﻿namespace Video_Violation
{
    internal class CardViewHyperLinkColumn
    {
    }
}